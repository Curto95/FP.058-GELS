package gels.vista;

public class OnlineStore {
}
