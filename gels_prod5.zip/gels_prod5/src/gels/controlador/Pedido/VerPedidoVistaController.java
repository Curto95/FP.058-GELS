//Declaramos el paquete del que viene este archivo
package gels.controlador.Pedido;
//Declaramos las dependencias

import gels.controlador.Controlador;
import gels.vista.data.ArticuloView;
import gels.vista.data.ClienteView;
import gels.vista.data.PedidoView;
import gels.zap.throwable.DbConnectionException;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

//Declaramos la clase
public class VerPedidoVistaController {

    @FXML
    private TableView<PedidoView> tblMosPed;
    @FXML
    private TableColumn<PedidoView, Long> colIdPediMos;
    @FXML
    private TableColumn<PedidoView, Integer> colCantPedMos;
    @FXML
    private TableColumn<PedidoView, Date> colFechPedMos;
    @FXML
    private TableColumn<PedidoView, ArticuloView> colArtPedMos;
    @FXML
    private TableColumn<PedidoView, Float> colPrecPedMos;
    @FXML
    private TableColumn<PedidoView, Boolean> colEstPedMos;
    @FXML
    private TableColumn<PedidoView, ClienteView> colIdCliePedMos;
    @FXML
    private Button btnVoldPedMos;
    private Controlador controlador;
    @FXML
    private Button btnIdModPed;
    @FXML
    private Label lblIdPedMosPed;
    @FXML
    private TextField txtIdPedMosPed;
//Try catch para el controller de la vista del pedido

    public VerPedidoVistaController() {
        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void initialize() {
        // Configura las columnas de la tabla.
        colIdPediMos.setCellValueFactory(new PropertyValueFactory<>("id_pedido"));
        colCantPedMos.setCellValueFactory(new PropertyValueFactory<>("cantidadArticulo"));
        colFechPedMos.setCellValueFactory(new PropertyValueFactory<>("fechaPedido"));
        colArtPedMos.setCellValueFactory(new PropertyValueFactory<>("articulo"));
        colArtPedMos.setCellFactory(column -> {
            return new TableCell<PedidoView, ArticuloView>() {
                @Override
                protected void updateItem(ArticuloView item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item == null || empty) {
                        setText(null);
                    } else {
                        setText(Integer.toString(item.getId_articulo()));
                    }
                }
            };
        });
        colPrecPedMos.setCellValueFactory(new PropertyValueFactory<>("total"));
        colEstPedMos.setCellValueFactory(new PropertyValueFactory<>("pedidoEnviado"));
        colIdCliePedMos.setCellValueFactory(new PropertyValueFactory<>("cli"));
        colIdCliePedMos.setCellFactory(column -> {
            return new TableCell<PedidoView, ClienteView>() {
                @Override
                protected void updateItem(ClienteView item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item == null || empty) {
                        setText(null);
                    } else {
                        setText(Long.toString(item.getIdCliente()));
                    }
                }
            };
        });
    }

    @FXML
    void mostrarPedidos() throws DbConnectionException {
        try {
            List<PedidoView> pedidos = controlador.obtenerPedidos(); // obtén la lista de pedidos
            tblMosPed.getItems().clear(); // Limpia la tabla antes de añadir los pedidos.

            for (PedidoView pedido : pedidos) {
                tblMosPed.getItems().add(pedido); // Añade cada pedido a la tabla.
            }

            // Podemos manejar el caso en que no haya pedidos si queremos.
            if (pedidos.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Información");
                alert.setHeaderText(null);
                alert.setContentText("No hay pedidos para mostrar");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Mostramos un mensaje de error si no se pueden obtener los pedidos de la base de datos.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Error al obtener pedidos de la base de datos.");
            alert.showAndWait();
        }
    }

    @FXML
    void volverMenPed(ActionEvent event) {
        try {
            // Cargamos el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Pedido/MenuPedidosVista.fxml"));

            // Creamos la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtenemos el escenario desde el evento y establecemos la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
