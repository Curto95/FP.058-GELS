//Declaramos el paquete del que viene este archivo
package gels.controlador.Pedido;
//Declaramos las dependencias

import gels.controlador.Controlador;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//Declaramos la clase
public class EnviarPedidoVistaController {

    @FXML
    private Label lblcodPedEnv;
    @FXML
    private TextField txtCodPedEnv;
    @FXML
    private Button btnEnvEnv;
    @FXML
    private Button btnVolvPedEnv;

    private Controlador controlador;

    public EnviarPedidoVistaController() {

        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void enviarPed(ActionEvent event) {
        try {
            int codigo = Integer.parseInt(txtCodPedEnv.getText());

            controlador.enviarPedido(codigo);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Pedido enviado correctamente");

            // Mostrar la alerta.
            alert.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Declaramos los metodos
    @FXML
    void volverMenPed(ActionEvent event) {
        try {
            // Cargamos el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Pedido/MenuPedidosVista.fxml"));

            // Creamos la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtenemos el escenario desde el evento y establecemos la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
