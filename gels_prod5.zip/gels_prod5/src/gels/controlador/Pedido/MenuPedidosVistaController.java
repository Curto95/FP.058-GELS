//Declaramos el paquete del que viene este archivo
package gels.controlador.Pedido;
//Declaramos las dependencias

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

//Declaramos la clase
public class MenuPedidosVistaController {

    @FXML
    private Label lblMenuPed;
    @FXML
    private Button btnMenVerPed;
    @FXML
    private Button btnMenAñaPedi;
    @FXML
    private Button btnMenEnviPedi;
    @FXML
    private Button btnMenElimPedi;
    @FXML
    private Button btnMenVolvPedi;

    //Creamos un metodo para ver los pedidos
    @FXML
    void verPedidos(ActionEvent event) {
        try {
            // Cargar el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Pedido/VerPedidoVista.fxml"));

            // Crear la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtener el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Creamos un metodo para añadir los pedidos
    @FXML
    void añadirPedidos(ActionEvent event) {
        try {
            // Cargar el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Pedido/AñadirPedidosVista.fxml"));

            // Crear la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtener el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Creamos un metodo para eliminar los pedidos
    @FXML
    void eliminarPedidos(ActionEvent event) {
        try {
            // Cargar el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Pedido/EliminarPedidoVista.fxml"));

            // Crear la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtener el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Creamos un metodo para enviar pedidos
    @FXML
    void enviarPedidos(ActionEvent event) {
        try {
            // Cargar el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Pedido/EnviarPedidoVista.fxml"));

            // Crear la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtener el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Creamos un metodo para volver a gestion
    @FXML
    void volverGestion(ActionEvent event) {
        try {
            // Cargamos el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/MenuGestion/GestionVista.fxml"));

            // Creamos la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtenemos el escenario desde el evento y establecemos la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
