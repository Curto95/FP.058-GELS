//Declaramos el paquete del que viene este archivo
package gels.controlador.Pedido;
//Declaramos las dependencias
import gels.controlador.Controlador;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//Declaramos la clase
public class AñadirPedidosVistaController {

    @FXML
    private Label lblCantPedAña;
    @FXML
    private Label lblFechPedAña;
    @FXML
    private Label lblIdArtPedAña;
    @FXML
    private TextField txtCantPedAña;
    @FXML
    private TextField txtFechPedAña;
    @FXML
    private TextField txtIdArtPedAña;
    @FXML
    private Button btnCreaPedAña;
    @FXML
    private Button btnVolPedAña;
    @FXML
    private Label lblIdCliPedAña;
    @FXML
    private TextField txtNifCliPedAña;

    private Controlador controlador;

    //Creamos un metodo para el controlador de la vista de añadir pedidos
    public AñadirPedidosVistaController() {

        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Creamos un metodo para el boton de añadir pedidos

    @FXML
    void BtnAñadirPed(ActionEvent event) {
        try {
            String nifCliente = txtNifCliPedAña.getText();
            int idArticulo = Integer.parseInt(txtIdArtPedAña.getText());
            int cantidadArticulo = Integer.parseInt(txtCantPedAña.getText());

            // Creamos el formato de la fecha.
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
            // Convertir la cadena a un objeto Date.
            Date fechaPedido = format.parse(txtFechPedAña.getText());

            // Llamamos al metodo del controlador que añade el artículo, pasando los datos recolectados.
            controlador.addPedidos(nifCliente, idArticulo, cantidadArticulo, fechaPedido);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Pedido añadido correctamente");

            // Mostramos la alerta.
            alert.showAndWait();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    void volverMenPed(ActionEvent event) {
        try {
            // Cargamos el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Pedido/MenuPedidosVista.fxml"));

            // Creamos la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtenemos el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
