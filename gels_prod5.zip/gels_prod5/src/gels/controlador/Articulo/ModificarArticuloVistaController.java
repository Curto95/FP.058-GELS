//Declaramos el paquete del que viene este archivo
package gels.controlador.Articulo;
//Declaramos las dependencias
import gels.controlador.Controlador;
import gels.vista.data.ArticuloView;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//Creamos la clase
public class ModificarArticuloVistaController{
    @FXML
    private TextField txtModArt;
    @FXML
    private Label lblModArt;
    @FXML
    private TextField tvtModDescArt;
    @FXML
    private TextField txtModPrecArt;
    @FXML
    private TextField txtModEnvArt;
    @FXML
    private TextField txtModPrepArt;
    @FXML
    private Label lblModDesArt;
    @FXML
    private Label lblModPrecArt;
    @FXML
    private Label lblModEnvArt;
    @FXML
    private Label lblModPrepArt;
    @FXML
    private Button btnModGuardArt;
    @FXML
    private Button btnModVolvArt;

    private Controlador controlador;
    //Creamos el metodo del controller de modificar articulo vista con un try catch que cree un nuevo controlador
    //Y si no devuelva la traza del error
    public ModificarArticuloVistaController(){
   
        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Creamos el metodo de modificar articulo
    @FXML
void modArticulo(ActionEvent event){
    try {
        int id_articulo = Integer.parseInt(txtModArt.getText());
        String descripcion = tvtModDescArt.getText();
        float pvp = Float.parseFloat(txtModPrecArt.getText());
        float precioEnvio = Float.parseFloat(txtModEnvArt.getText());
        int tiempoPrepEnvio = Integer.parseInt(txtModPrepArt.getText());

        ArticuloView av = new ArticuloView(id_articulo, descripcion, pvp, precioEnvio, tiempoPrepEnvio);
        
        controlador.actualizarArticulo(av);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText("Artículo actualizado correctamente");

        // Mostrar la alerta.
        alert.showAndWait();

    } catch (Exception e) {
        e.printStackTrace();
    }
}
//Creamos el metodo de volver menu articulo
 @FXML
    void volverMenArt(ActionEvent event) {
         try {
        // Cargar el FXML de GestionVista
        Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Articulo/MenuArticuloVista.fxml"));

        // Crear la nueva escena
        Scene gestionVistaScene = new Scene(gestionVista);

        // Obtener el escenario desde el evento y establecer la nueva escena
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(gestionVistaScene);
        window.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
    }     
    
}
