//Declaramos el paquete del que viene este archivo
package gels.controlador.Articulo;
//Declaramos las dependencias

import gels.controlador.Controlador;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//Declaramos el controlador de la vista de eliminar articulo
public class EliminarArticuloVistaController {

    @FXML
    private TextField txtEliCodArt;
    @FXML
    private Label lblEliCodArt;
    @FXML
    private Button btnEliEliArt;
    @FXML
    private Button btnEliVolvArt;

    private Controlador controlador;

    //Declaramos un try catch dentro que realice la tarea de ejecutar un nuevo controlador y si no, muestre la traza de error
    public EliminarArticuloVistaController() {

        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Declaramos eliminar articulo
    @FXML
    void eliminarArt(ActionEvent event) {
        try {
            int id_articulo = Integer.parseInt(txtEliCodArt.getText());

            controlador.eliminarArticulo(id_articulo);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Artículo eliminado correctamente");

            // Mostramos la alerta.
            alert.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Declaramos volver al menu articulo
    @FXML
    void volverMenArt(ActionEvent event) {
        try {
            // Cargamos el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Articulo/MenuArticuloVista.fxml"));

            // Creamos la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtenemos el escenario desde el evento y establecemos la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
