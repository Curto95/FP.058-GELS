//Declaramos el paquete del que viene este archivo
package gels.controlador.Articulo;
//Declaramos las dependencias
import gels.controlador.Controlador;
import gels.vista.data.ArticuloView;
import gels.zap.throwable.DbConnectionException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

//Declaramos la clase
public class VerArticulosVistaController {

    @FXML
    private TableView<ArticuloView> tblVerArt;
    @FXML
    private TableColumn<ArticuloView, Integer> colVerIdArt;
    @FXML
    private TableColumn<ArticuloView, String> colVerDescArt;
    @FXML
    private TableColumn<ArticuloView, Float> colVerPrecArt;
    @FXML
    private TableColumn<ArticuloView, Float> colVerGastEnvi;
    @FXML
    private TableColumn<ArticuloView, Integer> colVerPrepArt;
    @FXML
    private Button btnVolvVerArt;
    private Controlador controlador;
    @FXML
    private Button btnIdArtMosArt;
    @FXML
    private Label lblIdArtMosArt;
    @FXML
    private TextField txtIdArtMosArt;

    @FXML
    private void initialize() {
        // Configuramos las columnas de la tabla.
        colVerIdArt.setCellValueFactory(new PropertyValueFactory<>("id_articulo"));
        colVerDescArt.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        colVerPrecArt.setCellValueFactory(new PropertyValueFactory<>("pvp"));
        colVerGastEnvi.setCellValueFactory(new PropertyValueFactory<>("precioEnvio"));
        colVerPrepArt.setCellValueFactory(new PropertyValueFactory<>("tiempoPrepEnvio"));
    }

    //Declaramos ver articulos vista controller
    public VerArticulosVistaController() {

        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Declaramos el metodo de mostrar articulos
    @FXML
    void mostrarArticulo(ActionEvent event) throws DbConnectionException {
        try {
            int idArticulo = Integer.parseInt(txtIdArtMosArt.getText()); // 1
            ArticuloView av = controlador.mostrarArticulo(idArticulo); // 2
            if (av != null) {
                tblVerArt.getItems().clear(); // Limpia la tabla antes de añadir el nuevo artículo.
                tblVerArt.getItems().add(av); // Añade el artículo a la tabla.
            } else {
                // Muestra un mensaje de error si el artículo no existe.
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("No se encontró ningún artículo con el ID " + idArticulo);
                alert.showAndWait();
            }
        } catch (NumberFormatException e) {
            // Muestra un mensaje de error si el ID del artículo ingresado no es un número.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("El ID del artículo debe ser un número.");
            alert.showAndWait();
        }
    }

    //Declaramos el metodo de volver al menu
    @FXML
    void volverMenArt(ActionEvent event) {
        try {
            // Cargar el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Articulo/MenuArticuloVista.fxml"));

            // Crear la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtener el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
