//Declaramos el paquete del que viene este archivo
package gels.controlador.Cliente;
//Declaramos las dependencias

import gels.controlador.Controlador;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//Declaramos la clase
public class AñadirClienteVistaController {

    @FXML
    private Label lblNifClieAña;
    @FXML
    private Label lblNomClieAña;
    @FXML
    private Label lblDomClieAña;
    @FXML
    private Label lblEmaClieAña;
    @FXML
    private Label lblTipClieAña;
    @FXML
    private TextField txtNifClieAña;
    @FXML
    private TextField txtNomClieAña;
    @FXML
    private TextField txtDomClieAña;
    @FXML
    private TextField txtEmaClieAña;
    @FXML
    private Button btnCreaClieAña;
    @FXML
    private Button btnVolvClieAña;
    @FXML
    private ChoiceBox<String> choTipClieAña;

    private Controlador controlador;
    private static final Map<String, Integer> CLIENT_TYPE_MAP = new HashMap<>();

    static {
        CLIENT_TYPE_MAP.put("ESTANDARD", 1);
        CLIENT_TYPE_MAP.put("PREMIUM", 0);

    }

    public void initialize() {
        // Añadimos las opciones al ChoiceBox.
        choTipClieAña.getItems().addAll("ESTANDARD", "PREMIUM");

        // Establecemoss la opción por defecto.
        choTipClieAña.setValue("ESTANDARD");
    }

    public AñadirClienteVistaController() {

        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Declaramos el metodo de boton añadir cliente
    @FXML
    void BtnAñadirClie(ActionEvent event) {
        try {
            String nombre = txtNomClieAña.getText();
            String domicilio = txtDomClieAña.getText();
            String nif = txtNifClieAña.getText();
            String email = txtEmaClieAña.getText();
            String selectedClientType = choTipClieAña.getValue();
            int tipoCliente = CLIENT_TYPE_MAP.get(selectedClientType);

            // Llamamos al método del controlador que añade el cliente, pasando los datos recolectados.
            controlador.addClientes(nombre, domicilio, nif, email, tipoCliente);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Cliente añadido correctamente");

            // Mostrar la alerta.
            alert.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Declaramos el metodo de volver menu cliente
    @FXML
    void volverMenCli(ActionEvent event) {
        try {
            // Cargamos el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Cliente/MenuClientesVista.fxml"));

            // Creamos la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtenemos el escenario desde el evento y establecemos la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
