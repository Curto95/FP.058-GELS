//Declaramos el paquete del que viene este archivo
package gels.controlador.Cliente;
//Declaramos las dependencias
import gels.controlador.Controlador;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//Declaramos la clase
public class EliminarClienteVistaController {

    @FXML
    private Button btnEliClieEli;
    @FXML
    private Label lblNifClieEli;
    @FXML
    private TextField txtNifClieEli;
    @FXML
    private Button btnVolvClieEli;

    private Controlador controlador;

    public EliminarClienteVistaController() {

        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Creamos un metodo para eliminar al cliente
    @FXML
    void eliminarClie(ActionEvent event) {
        try {
            String nif = txtNifClieEli.getText();

            controlador.eliminarCliente(nif);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Cliente eliminado correctamente");

            // Mostrar la alerta.
            alert.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Creamos un metodo para volver al menu principal
    @FXML
    void volverMenCli(ActionEvent event) {
        try {
            // Cargar el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Cliente/MenuClientesVista.fxml"));

            // Crear la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtener el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
