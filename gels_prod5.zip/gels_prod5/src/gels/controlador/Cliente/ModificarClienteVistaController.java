//Declaramos el paquete del que viene este archivo
package gels.controlador.Cliente;
//Declaramos las dependencias
import gels.controlador.Controlador;
import gels.vista.data.ArticuloView;
import gels.vista.data.ClienteView;
import gels.vista.data.ClienteView.TClienteView;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//Declaramos la clase
public class ModificarClienteVistaController{
    @FXML
    private Label lblIdClieModClie;
    @FXML
    private TextField txtIdClieModClie;
    @FXML
    private Label lblNomCliMod;
    @FXML
    private TextField txtNomCliMod;
    @FXML
    private Label lblNifClieMod;
    @FXML
    private TextField txtNifClieMod;
    @FXML
    private Label lblDomClieMod;
    @FXML
    private Label lblEmaClieMod;
    @FXML
    private Label lblTipClieMod;
    @FXML
    private TextField txtDomClieMod;
    @FXML
    private TextField txtEmaClieMod;
    @FXML
    private Button btnGuarClieMod;
    @FXML
    private Button btnVolClieMod;
    @FXML
    private ChoiceBox<String> choTipClieMod;
    
    
    private Controlador controlador;
    private static final Map<String, Integer> CLIENT_TYPE_MAP = new HashMap<>();
    static {
    CLIENT_TYPE_MAP.put("ESTANDARD", 1);
    CLIENT_TYPE_MAP.put("PREMIUM", 2);
    
}
    
    public void initialize() {
    // Añadimos las opciones al ChoiceBox.
    choTipClieMod.getItems().addAll("ESTANDARD", "PREMIUM");

    // Establecemos la opción por defecto.
    choTipClieMod.setValue("ESTANDARD");
}
    //Creamos un metodo para el controlador de la vista de modificamos cliente con el try catch
    public ModificarClienteVistaController(){
   
        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Creamos un metodo que modifique un cliente
   @FXML
   void modCliente(ActionEvent event){
    try {
        long idCliente = Integer.parseInt(txtIdClieModClie.getText());
        String nombre = txtNomCliMod.getText();
        String domicilio = txtNomCliMod.getText();
        String nif = txtNifClieMod.getText();
        String email = txtEmaClieMod.getText();
        String selectedClientType = choTipClieMod.getValue();
        int tipoClienteInt = CLIENT_TYPE_MAP.get(selectedClientType);
        
        // Convertimos el tipoClienteInt a TClienteView
        TClienteView tipoClienteView;
        if (tipoClienteInt == 1) {
            tipoClienteView = TClienteView.ESTANDARD;
        } else if (tipoClienteInt == 2) {
            tipoClienteView = TClienteView.PREMIUM;
        } else {
            throw new IllegalArgumentException("Invalid client type: " + tipoClienteInt);
        }

        ClienteView cv = new ClienteView(idCliente, nombre, domicilio, nif, email, tipoClienteView);
    
        controlador.actualizarCliente(cv);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText("Cliente actualizado correctamente");

        // Mostramos la alerta.
        alert.showAndWait();

    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
        e.printStackTrace();
    }
}
   //Creamos un metodo para volver al menu principal
    @FXML
    void volverMenCli(ActionEvent event) {
         try {
        // Cargamos el FXML de GestionVista
        Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Cliente/MenuClientesVista.fxml"));

        // Creamos la nueva escena
        Scene gestionVistaScene = new Scene(gestionVista);

        // Obtenemos el escenario desde el evento y establecemos la nueva escena
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(gestionVistaScene);
        window.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
    } 
    
}
