//Declaramos el paquete del que viene este archivo
package gels.controlador.Cliente;
//Declaramos las dependencias

import gels.controlador.Controlador;
import gels.vista.data.ArticuloView;
import gels.vista.data.ClienteView;
import gels.zap.throwable.DbConnectionException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

//Declaramos la clase
public class VerClientesVistaController {

    @FXML
    private TableView<ClienteView> tblVerClient;
    @FXML
    private TableColumn<ClienteView, String> colIdClienMos;
    @FXML
    private TableColumn<ClienteView, String> colNombClieMos;
    @FXML
    private TableColumn<ClienteView, String> colEmaClieMos;
    @FXML
    private TableColumn<ClienteView, String> colDomiClieMos;
    @FXML
    private TableColumn<ClienteView, String> colNifClieMos;
    @FXML
    private Button btnVolClieMos;
    @FXML
    private Button btnIdClieMosClie;
    @FXML
    private Label lblIdClieMosCli;
    @FXML
    private TextField txtIdClieMosClie;
    private Controlador controlador;

    @FXML
    //Creamos un metodo para realizar una inicialización
    private void initialize() {
        // Configuramos las columnas de la tabla.
        colIdClienMos.setCellValueFactory(new PropertyValueFactory<>("IdCliente"));
        colNombClieMos.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colEmaClieMos.setCellValueFactory(new PropertyValueFactory<>("email"));
        colDomiClieMos.setCellValueFactory(new PropertyValueFactory<>("domicilio"));
        colNifClieMos.setCellValueFactory(new PropertyValueFactory<>("nif"));
    }

    //Metodo para el controlador de vista de ver clientes
    public VerClientesVistaController() {

        try {
            this.controlador = new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Creamos un metodo que muestre un cliente
    @FXML
    void mostrarCliente(ActionEvent event) throws DbConnectionException {
        try {
            String nif = txtIdClieMosClie.getText(); // 1
            ClienteView cv = controlador.showCliente(nif); // 2
            if (cv != null) {
                tblVerClient.getItems().clear(); // Limpia la tabla antes de añadir el nuevo artículo.
                tblVerClient.getItems().add(cv); // Añade el artículo a la tabla.
            } else {
                // Muestra un mensaje de error si el artículo no existe.
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("No se encontró ningún cliente con el NIF " + nif);
                alert.showAndWait();
            }
        } catch (NumberFormatException e) {
            // Mostramos un mensaje de error si el ID del artículo ingresado no es un número.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("El NIF del cliente debe ser un String.");
            alert.showAndWait();
        }
    }

    //Creamos un metodo que vuelva al menu principal
    @FXML
    void volverMenCli(ActionEvent event) {
        try {
            // Cargamos el FXML de GestionVista
            Parent gestionVista = FXMLLoader.load(getClass().getResource("/gels/vista/Cliente/MenuClientesVista.fxml"));

            // Creamos la nueva escena
            Scene gestionVistaScene = new Scene(gestionVista);

            // Obtenemos el escenario desde el evento y establecer la nueva escena
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(gestionVistaScene);
            window.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
