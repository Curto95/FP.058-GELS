package gels.zap.throwable;

public class ClienteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8652943438009902120L;
	public ClienteException(String msg) {
		super(msg);
	}

}
