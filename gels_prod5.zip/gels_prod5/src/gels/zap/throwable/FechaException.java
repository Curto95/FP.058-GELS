package gels.zap.throwable;

public class FechaException extends Exception {

	private static final long serialVersionUID = 11L;

	public FechaException(String msg) {
		super(msg);
	}

}
