package gels.zap.throwable;

public class DbConnectionException extends Exception {

	private static final long serialVersionUID = 123L;
	public DbConnectionException(String msg) {
		super(msg);
	}


}
