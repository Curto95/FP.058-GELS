package gels.zap.throwable;

public class ArticuloException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8652943438009902120L;
	public ArticuloException(String msg) {
		super(msg);
	}

}
