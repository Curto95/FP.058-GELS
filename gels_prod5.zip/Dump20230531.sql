CREATE DATABASE  IF NOT EXISTS `gels` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `gels`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: gels
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articulo`
--

DROP TABLE IF EXISTS `articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articulo` (
  `idArticulo` varchar(10) NOT NULL,
  `Descripcion` varchar(250) DEFAULT NULL,
  `PvpVenta` float DEFAULT NULL,
  `GastosEnvio` float DEFAULT NULL,
  `TiempoPreparacion` int DEFAULT NULL,
  PRIMARY KEY (`idArticulo`),
  UNIQUE KEY `idArticulo_UNIQUE` (`idArticulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulo`
--

LOCK TABLES `articulo` WRITE;
/*!40000 ALTER TABLE `articulo` DISABLE KEYS */;
INSERT INTO `articulo` VALUES ('123456','prueba',7.8,5.8,10),('2356','Pepsi',5,4,3),('5264','Pez',5.6,2.3,4),('56','Cerveza',6.8,3.2,2),('58','Pan',5.6,5.2,7),('5874','Cocacola',5.3,3.2,2),('6','Palomita',6.3,4,3),('7845','Tankeray',56.3,5,2),('7855','Cafe',4.3,3,2),('789652','Lapiz',5.8,8.3,3),('8762','Agua',1,0.5,2),('8947','Fanta',3.5,2,3),('9632','Kas',6.2,3,5),('987654','prueba2',7.8,6,4);
/*!40000 ALTER TABLE `articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `email` varchar(45) NOT NULL,
  `Nombre` varchar(45) DEFAULT NULL,
  `Domicilio` varchar(100) DEFAULT NULL,
  `Nif` varchar(9) DEFAULT NULL,
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `id_eMail_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES ('Juanito@juanito.com','Juanito','C/Juanito, 7','478145I',2),('killako@killako.com','Killako','C/killako, 6','54178F',3),('MariadelaO@MariadelaO.com','MariadelaO','MariadelaO','41584L',4),('Silvia@silvia.com','Silvia','C/Silvia, 8','5412478A',5),('toni@toni.com','Toni','C/Toni, 5','875694J',6),('toño@toñi.com','Toñi','C/Toñi, 4','874514T',7),('xisca@xisca.com','Xisca','C/Xisca, 45','416518D',8),('paco@paco.com','Paco','Paco','45783',13),('ana@ana.com','Ana','C/ana','4712H',14),('pepito@pepito.com','Pepito','C/pepito','7895',15),('prueba1@prueba.com','prueba1','C/prueba1, 1','555587P',16),('probiga@probiga.com','probiga','probiga','5555587P',17),('prueba2@prueba2.com','prueba2','C/prueba2, 2','6666678P',18),('premium@prueba2.com','premium','C/prueba2, 2','666645P',19);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_estandard`
--

DROP TABLE IF EXISTS `cliente_estandard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente_estandard` (
  `id_cliente` int NOT NULL,
  `calculo_anual` float DEFAULT NULL,
  `descuento_envio` float DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  CONSTRAINT `cliente_estandard_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_estandard`
--

LOCK TABLES `cliente_estandard` WRITE;
/*!40000 ALTER TABLE `cliente_estandard` DISABLE KEYS */;
INSERT INTO `cliente_estandard` VALUES (18,0,0);
/*!40000 ALTER TABLE `cliente_estandard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_premium`
--

DROP TABLE IF EXISTS `cliente_premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente_premium` (
  `id_cliente` int NOT NULL,
  `calculo_anual` float DEFAULT NULL,
  `descuento_envio` float DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  CONSTRAINT `cliente_premium_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_premium`
--

LOCK TABLES `cliente_premium` WRITE;
/*!40000 ALTER TABLE `cliente_premium` DISABLE KEYS */;
INSERT INTO `cliente_premium` VALUES (4,0,0),(13,0,0),(14,0,0),(15,0,0),(16,0,0),(17,0,0),(19,0,0);
/*!40000 ALTER TABLE `cliente_premium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedido` (
  `idPedido` int NOT NULL AUTO_INCREMENT,
  `Cantidad` int DEFAULT NULL,
  `FechaHora` date DEFAULT NULL,
  `idArticuloPedido` varchar(10) DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `pedido_enviado` tinyint(1) DEFAULT NULL,
  `id_cliente` int DEFAULT NULL,
  PRIMARY KEY (`idPedido`),
  UNIQUE KEY `idPedido_UNIQUE` (`idPedido`),
  KEY `idArticuloPedido_idx` (`idArticuloPedido`),
  KEY `fk_cliente_pedido` (`id_cliente`),
  CONSTRAINT `fk_cliente_pedido` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`),
  CONSTRAINT `idArticuloPedido` FOREIGN KEY (`idArticuloPedido`) REFERENCES `articulo` (`idArticulo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
INSERT INTO `pedido` VALUES (1,5,'2023-03-14','2356',15,0,3),(4,4,'2023-02-13','56',24,1,4),(5,50,'2023-05-01','7845',2820,0,15);
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-31 22:27:45
